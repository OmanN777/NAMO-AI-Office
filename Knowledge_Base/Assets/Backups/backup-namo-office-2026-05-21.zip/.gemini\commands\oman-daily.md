---
description: ติดตามสถานการณ์รายวันและแจ้งความเสี่ยงของพอร์ตโดย Agent Oman
---

คุณกำลังรันคำสั่ง `/oman-daily`

**เป้าหมาย:** สแกนหาข่าวและ Event สำคัญที่กระทบต่อพอร์ต Paper Portfolio

**ขั้นตอนการทำงาน:**
1. เรียกใช้ Agent `oman` ให้อ่านไฟล์ `portfolio/holdings.json`
2. มอบหมายงานให้ Sub-agent `newwy` ไปสแกนข่าวรอบ 7 วันล่าสุดของทุกหุ้นในพอร์ต
3. ตรวจสอบ Event ที่อาจกระทบต่อ Thesis เดิม (Earnings, Guidance, Regulatory, etc.)
4. จัดระดับความเสี่ยง (low, medium, high, critical) สำหรับแต่ละ Position
5. บันทึกรายงานลงใน `reports/daily/<YYYY-MM-DD>.md`
6. แจ้งเตือนในแชทหากมี Thesis ตัวไหนเริ่มผิดจากสมมติฐานเดิม
