---
description: เริ่มต้นพอร์ตจำลอง $30,000 USD โดย Agent Oman
---

คุณกำลังรันคำสั่ง `/oman-init`

**เป้าหมาย:** สร้างพอร์ตเริ่มต้นและคัดเลือกหุ้นเข้าพอร์ต

**ขั้นตอนการทำงาน:**
1. เรียกใช้ Agent `oman` เพื่อวิเคราะห์Candidate หุ้น (ถ้ามีใน KB หรือรวบรวมใหม่)
2. คัดเลือกหุ้น 3-10 ตัวที่ตรงตามปรัชญา Aggressive Growth & Technical Excellence
3. เขียน Investment Thesis และกำหนด Kill Conditions (2-3 ข้อ) สำหรับแต่ละตัว
4. กำหนดเงินลงทุนเริ่มต้น (Initial NAV) ที่ $30,000 และ Allocation ของแต่ละหุ้น
5. สร้างไฟล์เริ่มต้น:
   - `portfolio/holdings.json`
   - `portfolio/nav_history.md`
   - `portfolio/transactions.log`
   - `memory/lessons_learned.md`
6. แสดงสรุปพอร์ตเริ่มต้นในแชท
