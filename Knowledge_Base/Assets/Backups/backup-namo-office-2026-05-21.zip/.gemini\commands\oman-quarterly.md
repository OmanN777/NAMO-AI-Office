---
description: ประเมินพอร์ตหลังฤดูกาลประกาศงบโดย Agent Oman
---

คุณกำลังรันคำสั่ง `/oman-quarterly`

**เป้าหมาย:** วิเคราะห์ Earnings Transcript และตัดสินใจ Verdict สำหรับ Position

**ขั้นตอนการทำงาน:**
1. เรียกใช้ Agent `oman` โดยมอบหมายงานให้ `earnchan` และ `fundamentokung` อ่าน Transcript และ 10-Q/K ล่าสุด
2. ประเมินสถานะ (intact, evolving, invalidated) โดยอ้างอิง Quote และตัวเลขจริง
3. สร้าง Verdict และ Recommendation สำหรับช่วงไตรมาสถัดไป
4. บันทึกรายงานลงใน `reports/quarterly/<YYYY-QN>.md`
5. หาก Thesis ตัวไหน `invalidated` ให้วางแผน Sell หรือ Exit ทันที
