---
description: วิเคราะห์และอัปเดตพอร์ตประจำสัปดาห์โดย Agent Oman
---

คุณกำลังรันคำสั่ง `/oman-weekly`

**เป้าหมาย:** ประเมินความแข็งแกร่งของ Thesis และแนะนำ Action (Buy, Hold, Trim, Sell)

**ขั้นตอนการทำงาน:**
1. เรียกใช้ Agent `oman` ให้อัปเดตราคาล่าสุดของทุก Position (อ้างอิงแหล่งที่เชื่อถือได้)
2. ประเมินสถานะแต่ละตัว (intact, evolving, at-risk)
3. วิเคราะห์ความผิดพลาดหรือสิ่งที่เรียนรู้ในสัปดาห์นี้ บันทึกลงใน `memory/lessons_learned.md`
4. แนะนำ Action และปรับเปลี่ยน Sizing หากจำเป็น
5. อัปเดต NAV ล่าสุดลงใน `portfolio/nav_history.md`
6. บันทึกรายงานลงใน `reports/weekly/<YYYY-WW>.md`
