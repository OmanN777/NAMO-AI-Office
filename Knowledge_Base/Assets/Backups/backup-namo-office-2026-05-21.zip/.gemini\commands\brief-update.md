# Command: brief-update
# Description: รวบรวมข้อมูลวิจัยจาก Sub-agents และบันทึกลงในไฟล์ Brief รายหุ้น (Knowledge Compounding)

## วิธีใช้งาน
- `/brief-update [TICKER]`

## ขั้นตอนการทำงาน (Logic)
1. **Gather Data:** อ่านข้อมูลล่าสุดจาก Sub-agents ที่เกี่ยวข้องกับหุ้นตัวนั้น:
   - ข้อมูล 10-K จาก `fundamentokung`
   - ข้อมูล Earnings จาก `earnchan`
   - ข้อมูล ข่าว/Sentiment จาก `newwy`
2. **Synthesize:** สรุปเนื้อหาให้กระชับ แบ่งเป็นหัวข้อหลัก:
   - **Competitive Moat:** (จาก fundamentokung)
   - **Financial Health:** (จาก earnchan)
   - **Market Buzz:** (จาก newwy)
3. **Archive:** 
   - หากไฟล์ `briefs/[TICKER].md` ยังไม่มี ให้สร้างใหม่
   - หากมีอยู่แล้ว ให้ทำการอัปเดตข้อมูลส่วนที่ใหม่กว่า หรือเพิ่มส่วน "Latest Insight" ต่อท้าย
4. **Notify Dashboard:** ข้อมูลที่บันทึกจะถูกดึงไปแสดงผลในหน้า Stock Intelligence ทันที

## กฎการบันทึก
- ห้ามเขียนซ้ำซ้อน
- ต้องระบุวันที่อัปเดต (Last Updated) เสมอ
- เน้นเฉพาะข้อมูลที่เป็น Fact และ Insight ที่กระทบต่อ Thesis ของ Oman
