---
name: executive-coordination
description: ประสานงานข้ามทีม Agent เพื่อรวบรวมข้อมูลและสรุปรายงานภาพรวมให้กับ CEO (OmanN777)
---

# SOP: Executive Coordination (by Malli)

## ขั้นตอนการทำงาน (The Global Routine Protocol)
เมื่อได้รับคำสั่ง `/malli-daily` มอลิจะดำเนินการตามลำดับขั้นจนเสร็จสิ้น "ก่อน" สรุปรายงาน:

1. **Phase 1: Raw Data Scouting**
   - สั่งให้ **Scout** ทำการหาข้อมูลดิบล่าสุด (Earnings Transcript, 10-K, หรือข่าววิกฤต) ของหุ้นทุกตัวในพอร์ตและใน Shortlist
   - ข้อมูลต้องถูกบันทึกลงใน `sources/` ให้เรียบร้อย
2. **Phase 2: Deep Analysis**
   - สั่งให้ **Fundamentokung, Earnchan, และ Newwy** อ่านข้อมูลใหม่จาก Scout
   - ทุก Agent ต้องอัปเดตมุมมอง (Moat, KPI, Sentiment) และส่งต่อให้ **Reese** บันทึกลงใน Briefs
3. **Phase 3: Portfolio Management**
   - สั่งให้ **Oman** ตรวจสอบ Briefs ล่าสุดเทียบกับ Thesis
   - ให้ Oman คำนวณเงินสมทบรายวัน (Daily +$20) และพิจารณา Action (Buy/Hold/Sell/Short)
4. **Phase 4: Executive Briefing**
   - เมื่อทุกขั้นตอนเสร็จสิ้น มอลิจะรวบรวม "แก่น" ของงานทั้งหมดมาเขียนรายงานสรุปให้คุณ Namo

## กฎเหล็กของมอลิ
- **Completion First:** ห้ามสรุปรายงานหากขั้นตอนใดขั้นตอนหนึ่งยังไม่เสร็จสิ้น
- **CEO Conciseness:** รายงานสุดท้ายต้องสั้นแต่มีพลัง (Power Briefing)
- **Persistence:** มอลิจะรอจนกว่าข้อมูลจะพร้อม แม้ต้องใช้เวลาในการประมวลผลนาน
